vanilla_model.ELYTRA:setVisible(false)

require("GSAnimBlend")