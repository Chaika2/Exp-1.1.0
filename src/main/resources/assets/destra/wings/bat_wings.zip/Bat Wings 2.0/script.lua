-- lib reqs --
require("GSAnimBlend")
--also needs EZanims
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
animations.model.dive:setBlendTime(8)

function events.tick() --on each tick. 20/second
    --for variable wing flapping animation speed--
    local speed = vectors.vec3(math.abs(player:getVelocity()[1]),math.abs(player:getVelocity()[2]),math.abs(player:getVelocity()[3])) -- getting the player's velocity and assigning it to this variable
    local totalspeed = speed[1]+speed[2]+speed[3] --all the speed
    local velocityvirt= vectors.vec3(math.abs(player:getVelocity()[1]),player:getVelocity()[2],math.abs(player:getVelocity()[3])) --making a vec3 but the y velocity isnt abs
    local velocityvirtflat = velocityvirt[1]+velocityvirt[2]+velocityvirt[3] --cant do discreet math with a vector3 so i have this
    local blendweight = velocityvirtflat/2 --modify this variable to change strength of flapping anim
    local lookvirt = math.clamp(player:getLookDir()[2], 0, 1) * 0.7 --this is used to give extra flap at low speeds when looking up, make it look like you're properly taking off
    local flappyBlend = math.clamp(blendweight + lookvirt, 0, 1.5) --final blend weight math, clamped so it doesnt get too strong
    local flappySpeed = (velocityvirtflat * 0.6) + lookvirt --final anim speed math
    local contrialPrereq = 1 --how fast totalspeed has to be in order to spawn contrails.
    local diveBlend = math.abs(math.clamp(player:getLookDir()[2], -1, -0.3))
    if player:isGliding() then
        animations.model.flappy:play()
        if totalspeed >= contrialPrereq and world:getTime() % 2 == 0 then --contrails! If you're erroring here, its probably because you changed the model path
            particles:newParticle("minecraft:mycelium",
                models.model.root.Body.Wings.LeftWing.leftportion.leftelbow.leftpalm.leftfinger1.leftforefinger1.claw:partToWorldMatrix():apply())
            particles:newParticle("minecraft:mycelium",
                models.model.root.Body.Wings.RightWing.rightportion.rightelbow.rightpalm.rightfinger1.rightforefinger1.claw5:partToWorldMatrix():apply())
        else
        end
        animations.model.flappy:setSpeed(flappySpeed)
        animations.model.flappy:setBlend(flappyBlend)
        if player:getLookDir()[2] <= -0.3 then
            --log(diveBlend)
            animations.model.dive:play()
            animations.model.dive:setBlend(diveBlend)
        else
            animations.model.dive:stop()
        end
    else
        animations.model.flappy:stop()
        animations.model.dive:stop()
    end
end
