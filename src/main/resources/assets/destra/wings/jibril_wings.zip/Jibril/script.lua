--HI

--hide vanilla model--
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

--Halo--
animations.model.halo:play()

--Hair, Boobs and Ears physics--
local squapi = require("SquAPI")

local physBone = require('physBoneAPI')

local Tail
local tail2
local tail3
local Tail_2
local tail2_2
local tail2_3

function events.entity_init()
	physBone:setPreset("tail1",3.6,25,nil,1,nil,vec(-0.25,-1,0.25),30)
	physBone:setPreset("tail2",3.6,35,nil,1,nil,vec(-0.25,-1,0.25),20)

	tail1 = models.model.root.Head.Hair.Tail:newPhysBone("tail1")
	Tail2 = models.model.root.Head.Hair.Tail.tail2:newPhysBone("tail2")
	Tail3 = models.model.root.Head.Hair.Tail.tail2.tail3:newPhysBone("tail1")
end

function events.entity_init()
	physBone:setPreset("tail3",3.6,25,nil,1,nil,vec(0.25,-1,0.25),30)
	physBone:setPreset("tail4",3.6,35,nil,1,nil,vec(0.25,-1,0.25),20)

	tail_2 = models.model.root.Head.Hair.Tail_2:newPhysBone("tail3")
	Tail2_2 = models.model.root.Head.Hair.Tail_2.tail2_2:newPhysBone("tail4")
	Tail2_3 = models.model.root.Head.Hair.Tail_2.tail2_2.tail2_3:newPhysBone("tail3")
end

local Chest

function events.entity_init()
	physBone:setPreset("Chest",1.5,nil,nil,1.5,nil,vec(0,0,-1),200,nil,vec(-90,0,0),nil,nil,nil,nil,0)
	
	chest = models.model.root.Body.Chest:newPhysBone("Chest")
end

--Eyes--

squapi.randimation:new(
    animations.model.Blink,    --animation
    200,    --(200) chanceRange
    true     --(false) isBlink
)

squapi.eye:new(
	models.model.root.Head.Eyes.LEye, --element
	nil, --(.25)leftdistance
	nil, --(1.25)rightdistance
	nil, --(.5)updistance
	nil --(.5)downdistance
)

squapi.eye:new(
	models.model.root.Head.Eyes.REye, --element
	1.25, --(.25)leftdistance
	0.25, --(1.25)rightdistance
	nil, --(.5)updistance
	nil --(.5)downdistance
)

--Wings--
if icarus then
    icarus:setWingsVisible(false)
end
local wingmodel = models.model
local anim = animations.model
local flyState
local expecFlap
anim.dive:setBlendTime(7)

--switch statement setup
local function switch(value)
	-- Handing `cases` to the returned function allows the `switch()` function to be used with a syntax closer to c code (see the example below).
	-- This is because lua allows the parentheses around a table type argument to be omitted if it is the only argument.
	return function(cases)

		-- The default case is achieved through the metatable mechanism of lua tables (the `__index` operation).
		setmetatable(cases, cases)

		local f = cases[value]
		if f then
			f()
		end
	end
end

--== scriptin ==--
require("GSAnimBlend")

local forwardBlend = 0

local forwardKeyState = false
function pings.forwardKeyPing(state)
    forwardKeyState = state
end
local forwardKey = keybinds:newKeybind("Forwards key", keybinds:getVanillaKey("key.forward"))
forwardKey.press = function()
    pings.forwardKeyPing(true)
end
forwardKey.release = function()
    pings.forwardKeyPing(false)
end

function FlapComplete()
  --log("Complete!", expecFlap, flyState)
  if flyState == "FLAP" and expecFlap >= 1 then
    --log("Flapping!")
    forwardBlend = 0.5
    anim.flap:play()
  end
  if (flyState ~= "FLAP") or (expecFlap == 0) then
    forwardBlend = 0
    --log("Stopping!")
    anim.flap:stop()
  end
  expecFlap = expecFlap - 1
end

function events.tick() --behold, my tick function. look upon it, ye mighty, and weep
  local speed = vectors.vec3(math.abs(player:getVelocity()[1]),math.abs(player:getVelocity()[2]),math.abs(player:getVelocity()[3])) -- getting the player's velocity and assigning it to this variable
  local totalspeed = speed[1]+speed[2]+speed[3] --all the speed
  local neglookvirt = math.clamp(player:getLookDir()[2], -1, 0)
  local diveDir = -0.3 --how far down the player has to be looking for dive to activate
  local flapPrereq = 2.2 --how fast the player has to be going for flap to activate
  local flappyBlendEQ = (totalspeed+0.3) / 2.5
  local flappyBlend = math.clamp(flappyBlendEQ + forwardBlend, 0.5, 1.3) --final blend clamp
  if not player:isGliding() then --hey are we flying or
    flyState = "GROUNDED"
  elseif player:getLookDir()[2] <= diveDir then --highest priority, if facing down far enough, so dive overrides other states
    flyState = "DIVE"
  elseif forwardKeyState then --second priority, if w key is pressed
    flyState = "FLAP"
    expecFlap = 1
  elseif (totalspeed > flapPrereq) and (flyState ~= "FLAP") then -- third priority, flap at high speeds, like when a rocket is used or returning from a dive
    flyState = "FLAP"
    expecFlap = 3
  elseif expecFlap == 0 then --lowest priority, gliding
    flyState = "GLIDE"
  end

  switch(flyState) {--switch statement for governing what to do during each state
    ["GROUNDED"] = function()
      --log("Case Ground")
      anim.dive:stop()
      anim.glide:stop()
    end,
    ["FLAP"] = function()
      --log("Case Flap")
      if anim.flap:isPlaying() == false and expecFlap ~= 0 then
        anim.flap:play()
        anim.flap:setBlend(flappyBlend)
      end
    end,
    ["DIVE"] = function()
      --log("Case Dive")
      anim.dive:play()
      anim.dive:setBlend(math.abs(neglookvirt) * 1.5)
      anim.glide:stop()
    end,
    ["GLIDE"] = function()
      --log("Case Glide")
      anim.glide:play()
      anim.dive:stop()
    end,
    __index = function()
      log("Error: State outside expected range. This is likely because the player is not loaded yet. Press F3+D to clear your chat.")
    end
  }
end