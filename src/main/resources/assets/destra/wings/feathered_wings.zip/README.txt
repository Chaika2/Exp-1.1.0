Adding to an existing model:
- Delete everything about the vanillaSkin in the script.lua and config.lua as well as "set classic/slim arms based on the player's model type". I recommend using ctrl+F to do it.
- Remember to copy the animations for the root and other 'vanilla' folders (LeftArm, RightArm, RightLeg, LeftLeg, Body) as they are animated in the various flight anims (elytra flap, hover & creative flight) and will make your avatar look jank if you don't.
- If anything is broken or you don't know how to do something, don't be afraid to come to the discord for help.

Using skins:
- Go into the folder named skins.
- Copy the contents of the folder for the skin you want.
- Paste it into the main model's textures folder, replacing the old files.

Texturing:
Use the template.png in the skins folder for texturing. Since Figura always checks for changes in the model/textures, I recommend having minecraft open alongside your art program of choice to see your changes in live-action.
Anything with an _e in front of it is an emissive file.
Downloading blockbench is highly recommend for an easier time texturing. With that, you can paint directly on the model!