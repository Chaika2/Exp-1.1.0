local EZAnims = require("scripts.EZAnims")
aylFAWModel = EZAnims:addBBModel(animations.model)

vanilla_model.PLAYER:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

-- Increase GSAnimBlend blend times (I despise the default blend times)
-- the ezanims one only sets ezanims blend times
local modelAnimations = animations:getAnimations()
for i, v in ipairs(modelAnimations) do
    modelAnimations[i]:setBlendTime(7)
end

local aylConfig = require("scripts.aylConfig")
config:setName("aylFAWConfig")

-- Defaults
local pageDefaults = {
    {"settings", "main", "minecraft:structure_void", "Settings", "Configuration saved over multiple sessions."},
    {"contrails", "settings", "minecraft:torch", "Contrails", "Particles will trail behind you in elytra flight."},
}
local settingDefaults = {
    {"hover", false, "main", true},
    {"vanillaSkin", true, "settings", true},
    {"elytraOnly", false, "settings", false},
    {"flapSFX", true, "settings", false},
    {"wingContrails", false, "contrails", false},
    {"contrailDensity", 1, "contrails", false},
    {"soaringOrDiving", false, "contrails", false},
    {"highVelocity", false, "contrails", false}
}
aylConfig:initialize(pageDefaults, settingDefaults, nil)

-- Hover
settings.hover.func = function(value, action, automatic)
    aylConfig:save("hover", value)
    if not automatic then
        sounds:playSound("entity.ender_dragon.flap", player:getPos(), 1, 1.25, false)
    end
    if value then
        aylFAWModel:setState("hover")
    else
        aylFAWModel:setState()
    end
end
aylConfig:action("hover", "minecraft:feather", "Hover", nil)
-- Vanilla skin
function pings.setVanillaSkin(isSlim)
	-- Set classic/slim arms based on the player's model type
    models.model.root.RightArm.rightArmSlim:setVisible(isSlim)
    models.model.root.RightArm.rightSleeveSlim:setVisible(isSlim)
    models.model.root.LeftArm.leftArmSlim:setVisible(isSlim)
    models.model.root.LeftArm.leftSleeveSlim:setVisible(isSlim)
    models.model.root.RightArm.rightArmClassic:setVisible(not isSlim)
    models.model.root.RightArm.rightSleeveClassic:setVisible(not isSlim)
    models.model.root.LeftArm.leftArmClassic:setVisible(not isSlim)
    models.model.root.LeftArm.leftSleeveClassic:setVisible(not isSlim)
    models.model.root.Head.head:setPrimaryTexture("SKIN")
    models.model.root.Head.hat:setPrimaryTexture("SKIN")
    models.model.root.Body.body:setPrimaryTexture("SKIN")
    models.model.root.Body.jacket:setPrimaryTexture("SKIN")
    models.model.root.RightArm.rightArmClassic:setPrimaryTexture("SKIN")
    models.model.root.RightArm.rightSleeveClassic:setPrimaryTexture("SKIN")
    models.model.root.RightArm.rightArmSlim:setPrimaryTexture("SKIN")
    models.model.root.RightArm.rightSleeveSlim:setPrimaryTexture("SKIN")
    models.model.root.LeftArm.leftArmClassic:setPrimaryTexture("SKIN")
    models.model.root.LeftArm.leftSleeveClassic:setPrimaryTexture("SKIN")
    models.model.root.LeftArm.leftArmSlim:setPrimaryTexture("SKIN")
    models.model.root.LeftArm.leftSleeveSlim:setPrimaryTexture("SKIN")
    models.model.root.RightLeg.rightLeg:setPrimaryTexture("SKIN")
    models.model.root.RightLeg.rightPants:setPrimaryTexture("SKIN")
    models.model.root.LeftLeg.leftLeg:setPrimaryTexture("SKIN")
    models.model.root.LeftLeg.leftPants:setPrimaryTexture("SKIN")
end
settings.vanillaSkin.func = function(value)
    aylConfig:save("vanillaSkin", value)
	if settings.vanillaSkin.value then
		isSlim = player:getModelType() == "SLIM"
		pings.setVanillaSkin(isSlim)
	end
end
aylConfig:action("vanillaSkin", "minecraft:armor_stand", "Vanilla Skin", "Reload required.\nUse your vanilla skin automatically. Turn this off if you want to use a different skin from your player.\nNote that the vanilla §omodel §r§7is always hidden and replaced with the modded model.")

-- Elytra only wings
function showWings(value)
    models.model.root.Body.rightWing:setVisible(value)
    models.model.root.Body.leftWing:setVisible(value)
    if value then
        if settings["hover"].value then
            aylFAWModel:setState("hover")
        else
            aylFAWModel:setState()
        end
    else
        aylFAWModel:setState("nowings")
    end
end
function setElytraOnly()
    showWings(player:getItem(5).id == "minecraft:elytra")
end
settings.elytraOnly.func = function(value)
    aylConfig:save("elytraOnly", value)
	if value then
        setElytraOnly()
    else
        showWings(true)
    end
end
aylConfig:action("elytraOnly", "minecraft:elytra", "Elytra Only", "Hides your wings while not wearing elytra.")
function events.tick()
    -- Hide wings when not wearing elytra if the toggle is on
    if settings["elytraOnly"].value then
        setElytraOnly()
    end
end

-- Flap SFX
settings.flapSFX.func = function(value)
    aylConfig:save("flapSFX", value)
end
aylConfig:action("flapSFX", "minecraft:jukebox", "Flap SFX", "Controls the flapping sounds from the creative flight & elytra flap animations, as well as the action wheel.")
function events.tick()
    -- Stop flap SFX if the toggle is on
	if not settings["flapSFX"].value then
        sounds:stopSound("entity.ender_dragon.flap")
	end
end

-- Wing contrails
settings.wingContrails.func = function(value)
    aylConfig:save("wingContrails", value)
end
aylConfig:action("wingContrails", "minecraft:redstone_torch", "Wing Contrails", "Particles will trail behind your wingtips.\nBy default, the particle is minecraft:firework. If you want to replace this, go into scripts/aylElytra.lua and change wingContrailParticle to your particle of choice.")
-- Contrail interval
settings.contrailDensity.func = function(value)
    aylConfig:iterate("contrailDensity", 1, 20, value)
end
aylConfig:action("contrailDensity", "minecraft:firework_star", "Contrail Density", "How many ticks to wait before spawning a new particle.\n1 will spawn a particle every tick, 2 will spawn a particle every two ticks, & 3 will spawn a particle every three ticks - so on and so on.", "Ticks: ")
-- Soaring or diving
settings.soaringOrDiving.func = function(value)
    aylConfig:save("soaringOrDiving", value)
end
aylConfig:action("soaringOrDiving", "minecraft:lantern", "Soaring Or Diving", "Contrails will only appear when soaring or diving.")
-- Soaring or diving
settings.highVelocity.func = function(value)
    aylConfig:save("highVelocity", value)
end
aylConfig:action("highVelocity", "minecraft:firework_rocket", "High Velocity", "Contrails will only appear at high velocities, such as when boosting with a firework rocket or diving.")