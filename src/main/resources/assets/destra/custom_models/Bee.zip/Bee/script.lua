---------------------------------------------------------------------------------------------------------------
---PLAYER MODEL ADJUSTMENTS---
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
models.model.whole.body.LeftArm.LeftItemPivot:setScale(0.8,0.8,0.8)
models.model.whole.body.RightArm.RightItemPivot:setScale(0.8,0.8,0.8)


---------------------------------------------------------------------------------------------------------------
---IDLE BODY MOVEMENTS---

animations.model.idle_1:setSpeed(0.3)
animations.model.idle_1:play()

animations.model.idle_2:setSpeed(0.15)
animations.model.idle_2:play()

animations.model.idle_3:setSpeed(0.3)
animations.model.idle_3:play()

animations.model.idle_4:setSpeed(0.3)
animations.model.idle_4:play()

animations.model.flying:setSpeed(3)
---------------------------------------------------------------------------------------------------------------
---ANIMATION SETUP---
local anims = require("lib.EZAnims")
local bunny = anims:addBBModel(animations.model)
bunny:setBlendTimes(0)

---------------------------------------------------------------------------------------------------------------
---HAIR PHYSICS---
local SwingingPhysics = require("lib.swinging_physics")

SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.front_hair, 0, { -2, 5, -0, 0, -5, 5 },
    nil, 0)
    SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.left_hair, 90, { -10, 10, -0, 0, -20, 5 },
    nil, 0)

    SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.left_hair.l_p, 90, { -15, 5, -0, 0, -20, 15 },
    nil, 1)

    SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.left_hair.l_p.left_ponytail, 90, { -15, 0, -0, 0, -10, 15 },
    nil, 2)
    SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.right_hair, -90, { -10, 10, -0, 0, -5, 20 },
    nil, 0)

    SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.right_hair.r_p, 90, { -15, 5, -0, 0, -20, 15 },
    nil, 1)

    SwingingPhysics.swingOnHead(models.model.whole.body.head.hair.right_hair.r_p.right_ponytail, 90, { -15, 0, -0, 0, -10, 15 },
    nil, 2)
    
---------------------------------------------------------------------------------------------------------------
---SQUAPI APPLICATIONS---
local squapi = require("lib.SquAPI")

---HEAD---
squapi.smoothHead:new(
    {
        models.model.whole.body,
        models.model.whole.body.head--element(you can have multiple elements in a table)
    },
		nil,    --(1) strength(you can make this a table too)
    nil,    --(0.1) tilt
    nil,    --(1) speed
    true     --(true) keepOriginalHeadPos
)

---EYES---
squapi.eye:new(
    models.model.whole.body.head.eyes.iris2,  --the eye element 
    0.5,  --(0.2) left distance
    0.5,  --(0.3) right distance
    0.7,  --(0.5) up distance
    0.7   --(0.5) down distance
)

squapi.eye:new(
    models.model.whole.body.head.eyes.iris,  --the eye element 
    0.5,  --(0.2) left distance
    0.5,  --(0.3) right distance
    0.7,  --(0.5) up distance
    0.7   --(0.5) down distance
)

---ARMS AND LEGS--- MAKES ROTATION SMALLER SO LOOKS LESS WONKY, SIMPLY DELETE IF NOT NEEDED
squapi.arm:new(
    models.model.whole.body.LeftArm, --element
    0.6, --(1) strength
    nil, --(false) isRight
    false  --(true) keepPosition
)

squapi.arm:new(
    models.model.whole.body.RightArm, --element
    0.6, --(1) strength
    true, --(false) isRight
    false  --(true) keepPosition
)

squapi.leg:new(
    models.model.whole.LeftLeg,    --element
    0.8,    --(1) strength
    false,    --(false) isRight
    nil     --(true) keepPosition
)
squapi.leg:new(
    models.model.whole.RightLeg,    --element
    0.8,    --(1) strength
    true,    --(false) isRight
    nil     --(true) keepPosition
)

squapi.ear:new(
    models.model.whole.body.head.antennaes.a1, --leftEar
    models.model.whole.body.head.antennaes.a2, --(nil) rightEar
    nil, --(1) rangeMultiplier
    false, --(false) horizontalEars
    nil, --(2) bendStrength
    false, --(true) doEarFlick
    3000, --(400) earFlickChance
    nil, --(0.1) earStiffness
    nil  --(0.8) earBounce
)

function events.render(delta, context)
    local rot_r = vanilla_model.RIGHT_LEG:getOriginRot()

    models.model.whole.body:setPos(nil, (math.sin(math.abs(rot_r.x/70)) *0.5), nil)


        local firstPerson=context=="FIRST_PERSON"
    models.model.RightArm2:setVisible(firstPerson)

end
