--#region SQUAPI SMOOTH TORSO

local sqp = require("SquAPI")

sqp.smoothHead:new(
    models.model.root.torso.body,
    0.3,
    nil,
    nil,
    false
)

sqp.smoothHead:new(
    models.model.root.torso.body.topbody.head,
    0.7,
    nil,
    nil,
    false
)

sqp.leg:new(models.model.root.legs.leftleg, 0.5, false, false)
sqp.leg:new(models.model.root.legs.rightleg, 0.5, true, false)

local _rot = 0;
function events.render(d)
    if not player:getVehicle() then
        _rot = math.lerp(_rot, vanilla_model.LEFT_LEG:getOriginRot().x / 4, d / 3)
        models.model.root.torso:setRot(0, _rot, _rot / 8)
    end
end

--#endregion



--#region RANDOM ANIMS

local animFreq = 100 -- measured in ticks
local animVar = 0.75 -- 0-1

local ramdomAnimations = {
    animations.model.fingertwitch,
    animations.model.fingertwitch2,
    animations.model.fingerspin,
}
animations.model.fingertwitch:setBlendTime(3)
animations.model.fingertwitch2:setBlendTime(3)
animations.model.fingerspin:setBlendTime(0)

local playRandom = animFreq

function events.tick()
    -- random anims

    playRandom = playRandom - 1

    if playRandom <= 0 then
        for _, ramdomAnim in ipairs(ramdomAnimations) do
            ramdomAnim:stop()
        end
        ramdomAnimations[math.random(#ramdomAnimations)]:play()

        playRandom = animFreq * (math.random() + 0.5) * animVar * 2
    end
end

--#endregion



--#region

animations.model.firstpersonidle:play()

local arms = models.model.root.torso.body.topbody.arms;
local pivotR = arms.rightarm.armrot.botarm_R.bothand_R.pivotrot.RightItemPivot;
local pivotL = arms.leftarm.botarm_L.bothand_L.pivotrotL.LeftItemPivot;

function events.render(delta, context)
    pivotL:setRot(animations.model.holdL:isPlaying() and
        vanilla_model.RIGHT_ARM:getOriginRot() * 0.1 or 0)

    pivotR:setRot(animations.model.holdR:isPlaying() and
        vanilla_model.LEFT_ARM:getOriginRot() * 0.1 or 0)
end

models.model.firstpersonarm:setVisible(false)
if host:isHost() then
    function events.render(d, c)
        local firstPerson = c == "FIRST_PERSON"
        models.model.firstpersonarm:setVisible(firstPerson):setParentType(firstPerson and "RightArm" or
            "None")
    end
end

function events.tick()
    -- holding item = finger activation
    animations.model.holdNoR:setPlaying(not animations.model.holdR:isPlaying(true))
    animations.model.holdNoL:setPlaying(not animations.model.holdL:isPlaying(true))
end

animations.model.holdNoR:setBlendTime(2)
animations.model.holdNoL:setBlendTime(2)


--#endregion


function events.tick()
    local hp = math.ceil(player:getHealth());
    models.model.root.torso.body.topbody.head.hp.hp1:setVisible(hp >= 0);
    models.model.root.torso.body.topbody.head.hp.hp2:setVisible(hp >= 5);
    models.model.root.torso.body.topbody.head.hp.hp3:setVisible(hp >= 10);
    models.model.root.torso.body.topbody.head.hp.hp4:setVisible(hp >= 15);
    models.model.root.torso.body.topbody.head.hp.hp5:setVisible(hp >= 20);
end
