vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.HELMET_ITEM:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)

models.model.root.torso.body.topbody.head.upperhead.googly.Rcutout:setPrimaryRenderType(
    "CUTOUT_CULL")
models.model.root.torso.body.topbody.head.upperhead.googly.Lcutout:setPrimaryRenderType(
    "CUTOUT_CULL")
models.model.root.torso.body.topbody.head.upperhead.googly.rightgoogle.rightgoogle_light
    :setSecondaryRenderType(
        "EMISSIVE")
models.model.root.torso.body.topbody.head.upperhead.googly.leftgoogle.leftgoogle_light
    :setSecondaryRenderType("EMISSIVE")
models.model.root.torso.body.topbody.head.hp:setSecondaryRenderType("EMISSIVE")

require("GSAnimBlend")
local anims = require("EZAnims")
local repo = anims:addBBModel(animations.model)
local SwingingPhysics = require("swinging_physics")
local swingOnHead = SwingingPhysics.swingOnHead
local swingOnBody = SwingingPhysics.swingOnBody


--#region LIMBS

animations.model.armrot:play()


function events.entity_init()
    swingOnBody(models.model.root.torso.body.topbody.arms.rightarm.armrot, 0, { -5, 5, -5, 5, -5, 5 })
    swingOnHead(
        models.model.root.torso.body.topbody.arms.rightarm.armrot.botarm_R.bothand_R.pivotrot
        .RightItemPivot, 0,
        { -20, 20, -20, 20, -50, 05 })
    swingOnHead(
        models.model.root.torso.body.topbody.arms.leftarm.botarm_L.bothand_L.pivotrotL.LeftItemPivot,
        0,
        { -20, 20, -20, 20, -50, 50 })
end

--#endregion



--#region ACTION WHEEL - SKINS, SHRINKING AND SELF DESTRUCT


local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)


--#region KING OF THE LOSERS


models.model.root.torso.body.topbody.head.upperhead.kingOTL:setVisible(false)
function pings.kotl(state)
    models.model.root.torso.body.topbody.head.upperhead.kingOTL:setVisible(state)
end

if host:isHost() then
    mainPage:newAction()
        :title("King Of The Losers")
        :hoverColor(1, 0, 0.3)
        :item("minecraft:golden_helmet")
        :toggleItem("minecraft:barrier")
        :onToggle(pings.kotl)
end



--#endregion


--#region SELF DESTRUCT

models.model.head_destroyed:setVisible(false)
local selfDest = false;
function pings.destruct(state)
    selfDest = state
    animations.model.destruct:setPlaying(state)
    models.model.head_destroyed:setVisible(state)
end

mainPage:newAction()
    :title("Self Destruct")
    :toggleTitle("Reconstruct")
    :hoverColor(1, 0, 0.3)
    :item("minecraft:tnt")
    :toggleItem("minecraft:white_bed")
    :onToggle(pings.destruct);


local selfDestParts = {
    models.model.root.legs,
    models.model.root.torso.body.botbody,
    models.model.root.torso.body.topbody.chest,
    models.model.root.torso.body.topbody.head.throat,
    models.model.root.torso.body.topbody.head.upperhead.mound,
    models.model.root.torso.body.topbody.arms,
}

for _, v in pairs(selfDestParts) do
    v:setSecondaryTexture("CUSTOM", textures["textures.destruct"]):setSecondaryRenderType("NONE")
end



local _selfDest = false;
local selfDestAnim = animations.model.destruct;
function events.tick()
    if _selfDest ~= selfDest then
        _selfDest = selfDest;

        for _, v in pairs(selfDestParts) do
            v:setSecondaryTexture("CUSTOM", textures["textures.destruct"]):setSecondaryRenderType(
                selfDest and "EMISSIVE" or "NONE")

            if not selfDest then
                v:setSecondaryColor(1)
            end
        end
    end

    if selfDest then
        local animtime = selfDestAnim:getTime()
        local cvalue = math.max((animtime - 0.2) * (animtime - 0.8), 0);
        models.model.root.legs:setSecondaryColor(cvalue)
        models.model.root.torso.body.botbody:setSecondaryColor(cvalue)
        models.model.root.torso.body.topbody.chest:setSecondaryColor(cvalue)
        models.model.root.torso.body.topbody.head.throat:setSecondaryColor(cvalue)
        models.model.root.torso.body.topbody.head.upperhead.mound:setSecondaryColor(cvalue)
        models.model.root.torso.body.topbody.arms:setSecondaryColor(cvalue)
    end
end

--#endregion


--#region GOOGLY EYES

local sqp = require("SquAPI")
local rightEyeSQP = sqp.eye:new(
    models.model.root.torso.body.topbody.head.upperhead.googly.rightgoogle
)


local leftEyeSQP = sqp.eye:new(
    models.model.root.torso.body.topbody.head.upperhead.googly.leftgoogle
)

local eyeLogic = {
    range = 1,
    gravity = 0.97,
    googly = models.model.root.torso.body.topbody.head.upperhead.googly,
    pos = vec(0, 0),
    _pos = vec(0, 0),
    lastHRot = vec(0, 0),
    currHRot = vec(0, 0),
    vel = vec(0, 0),
}

eyeLogic.leftEye = eyeLogic.googly.leftgoogle;
eyeLogic.rightEye = eyeLogic.googly.rightgoogle;

function events.tick()
    eyeLogic.headRot = vanilla_model.HEAD:getOriginRot()
end

-- googly eye physics options
local googlyMovementTbl = {
    {
        title = "Eye Physics: normal eyes",
        color = vectors.hexToRGB("22FF22"),
        func = function(d, c)
            events.render:remove("eyeLogic")
        end,
        init = function()
            rightEyeSQP:enable()
            leftEyeSQP:enable()
        end,
    },
    {
        title = "Eye Physics: physics only",
        color = vectors.hexToRGB("FF2222"),
        func = function(d, c)
            local e = eyeLogic;

            e.currHRot = player:getRot();
            e.vel = (e.currHRot - e.lastHRot) / 4

            e.pos.y = e.pos.y + e.vel.x
            e.lastHRot = e.currHRot;
            e.pos.x = e.pos.x - e.vel.y

            e.pos.x = math.clamp(e.pos.x, -e.range, e.range)
            e.pos.y = math.clamp(e.pos.y, -e.range, e.range)
            e.pos = e.pos * e.gravity;
            e._pos = math.lerp(e._pos, e.pos, d / 5)
            e.leftEye:setPos(e._pos.xy_)
            e.rightEye:setPos(e._pos.xy_)
        end,
        init = function()
            rightEyeSQP:disable()
            leftEyeSQP:disable()
            rightEyeSQP:zero()
            leftEyeSQP:zero()
        end,
    },
    --[[     {
        title = "Eye Physics: combo",
        color = vectors.hexToRGB("2222FF"),
        func = function(d, c)

        end,
        init = function ()
            rightEyeSQP:disable()
            leftEyeSQP:disable()
            rightEyeSQP:zero()
            leftEyeSQP:zero()
        end
    }, ]]
}


local movementMode = config:load("Mode") or 1;
local function changeMode(int)
    events.render:remove("eyeLogic")

    movementMode = int;
    config:save("Mode", movementMode)

    googlyMovementTbl[movementMode].init()
    events.render:register(googlyMovementTbl[movementMode].func, "eyeLogic")
end
changeMode(movementMode)

function pings.changeMode(int)
    changeMode(int)
end

if host:isHost() then
    function events.tick()
        if world.getTime() % 120 == 0 then
            pings.changeMode(movementMode)
        end
    end

    mainPage:newAction()
        :title("Change Eye Mode")
        :item("minecraft:ender_eye")
        :onScroll(function(dir, self)
            dir = dir > 0 and 1 or - 1
            movementMode = (movementMode - 1 + dir) % #googlyMovementTbl + 1
            self:title(googlyMovementTbl[movementMode].title)
                :color(googlyMovementTbl[movementMode].color)
        end)
        :onLeftClick(function()
            pings.changeMode(movementMode)
        end)
end


--#endregion




local skinTbl = {
    { title = "Skin: Grey",                   clr = "#6a7c82" },
    { title = "Skin: Dark Grey",              clr = "#5b5b5b" },
    { title = "Skin: Peach",                  clr = "#ff8484" },
    { title = "Skin: Red",                    clr = "#ff1e1e" },
    { title = "Skin: Maroon",                 clr = "#a44341" },
    { title = "Skin: Dark Brown",             clr = "#5a2f2e" },
    { title = "Skin: Cherry",                 clr = "#ff135c" },
    { title = "Skin: Magenta",                clr = "#ff3f8a" },
    { title = "Skin: Neon Pink",              clr = "#ff2daf" },
    { title = "Skin: Mauve",                  clr = "#ff8dd4" },
    { title = "Skin: Light Purple",           clr = "#cda3ff" },
    { title = "Skin: Purple",                 clr = "#a759f5" },
    { title = "Skin: Violet",                 clr = "#9a00a5" },
    { title = "Skin: Black",                  clr = "#503e63" },
    { title = "Skin: Dark Blue",              clr = "#4a4f8e" },
    { title = "Skin: Blue",                   clr = "#3049d6" },
    { title = "Skin: Azure Blue",             clr = "#5673ff" },
    { title = "Skin: Cyan",                   clr = "#01ace0" },
    { title = "Skin: Turquoise",              clr = "#21d6c3" },
    { title = "Skin: Light Blue",             clr = "#69ffe0" },
    { title = "Skin: Pale Green",             clr = "#93ff92" },
    { title = "Skin: Green",                  clr = "#48da69" },
    { title = "Skin: Neon Green",             clr = "#00ff21" },
    { title = "Skin: Jungle Green",           clr = "#86d718" },
    { title = "Skin: Dark Green",             clr = "#79a426" },
    { title = "Skin: Extra Dark Green",       clr = "#5e8b60" },
    { title = "Skin: Extra Extra Dark Green", clr = "#48744a" },
    { title = "Skin: Yellow",                 clr = "#ffe84c" },
    { title = "Skin: Orangeish Yellow",       clr = "#ffd112" },
    { title = "Skin: Dark Yellow",            clr = "#cba800" },
    { title = "Skin: Orange",                 clr = "#ff8100" },
    { title = "Skin: Reddish Orange",         clr = "#ff5b0e" },
    { title = "Skin: Caramel Brown",          clr = "#8f5939" },
    { title = "Skin: Coffee Brown",           clr = "#6e6733" },
    { title = "Skin: Light Brown",            clr = "#bc965e" },
}


local semibotColor = config:load("Skin") or 1;

local function applySkin(int)
    local clr = vectors.hexToRGB(skinTbl[int].clr);

    models.model.firstpersonarm:setColor(clr)
    models.model.Skull:setColor(clr)
    models.model.head_destroyed:setColor(clr)
    models.model.root.legs:setColor(clr)
    models.model.root.torso.body.botbody:setColor(clr)
    models.model.root.torso.body.topbody.chest:setColor(clr)
    models.model.root.torso.body.topbody.head.throat:setColor(clr)
    models.model.root.torso.body.topbody.head.upperhead.mound:setColor(clr)
    models.model.root.torso.body.topbody.arms:setColor(clr)
end

applySkin(semibotColor);

function pings.changeSkin(int)
    semibotColor = int;
    applySkin(semibotColor);
    config:save("Skin", semibotColor)
end



-- skin wheel
if host:isHost() then
    function events.tick()
        if world.getTime() % 200 == 0 then
            pings.changeSkin(semibotColor)
        end
    end
    
    mainPage:newAction()
        :title("Change Skin")
        :item("minecraft:armor_stand")
        :onScroll(function(dir, self)
            dir = dir > 0 and 1 or - 1
            semibotColor = ((semibotColor + dir - 1) % #skinTbl) + 1;
            self:title(skinTbl[semibotColor].title)
        end)
        :onLeftClick(function() pings.changeSkin(semibotColor); end);
end

--#endregion
