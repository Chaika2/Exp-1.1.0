


animations.model.crouching:setBlendTime(1)
animations.model.yap:setBlendTime(1)
animations.model.shrink:setBlendTime(0.5)


-- yapping

function pings.yapPing(state)
    animations.model.yap:setPlaying(state)
end

local yapkey = keybinds:newKeybind("Yap Key","key.keyboard.g")
yapkey.press = function() pings.yapPing(true) end
yapkey.release = function() pings.yapPing(false) end

-- full crouch

local isShrinkPressed;
function pings.shrinkPing()
	animations.model.shrink:play()
	isShrinkPressed = true;
end

local crouchkey = keybinds:newKeybind("Shrink Key","key.keyboard.p")

crouchkey.press = function() isShrinkPressed = true; pings.shrinkPing() end

function events.tick()
	-- shrink vs crouch
	if isShrinkPressed and animations.model.crouching:isPlaying() then
		animations.model.shrink:stop()
		isShrinkPressed = false
	end
end

-- extend and retract held items

local prUp, prDw;

function pings.changeItemDistance(up,pressing)
	if up then
		prUp = pressing;
	else
		prDw = pressing;
	end
end



local upArrow = keybinds:newKeybind("Move Item Forward", "key.keyboard.up")
:onPress(function () pings.changeItemDistance(true,true) end)
:onRelease(function () pings.changeItemDistance(true,false) end)

local downArrow = keybinds:newKeybind("Move Item Backward", "key.keyboard.down")
:onPress(function () pings.changeItemDistance(false,true) end)
:onRelease(function () pings.changeItemDistance(false,false) end)

local currentZ = 0
local targetZ = 0

function pings.syncDistance(int)
	targetZ = int;
end

local moveSpeed = 0.8         -- How much to move per tick while held
local smoothingFactor = .125    -- How quickly the position blends (higher = snappier)
local minZ, maxZ = -50, 5     -- Clamp range

function events.render(d)
    -- Check if keys are held down and adjust targetZ
    if prUp then
        targetZ = targetZ - moveSpeed
    elseif prDw then
        targetZ = targetZ + moveSpeed
    end
	targetZ = math.clamp(targetZ,minZ,maxZ)

    -- Apply exponential smoothing for smooth movement
    --currentZ = currentZ + (targetZ - currentZ) * smoothingFactor
    currentZ = math.lerp(currentZ, targetZ, d*smoothingFactor)

    -- Apply to the model only if the animation is playing
    if animations.model.holdR:isPlaying() then
        models.model.root.torso.body.topbody.arms.rightarm.armrot.botarm_R.bothand_R.pivotrot.RightItemPivot:setPos(currentZ/3, currentZ, currentZ/2)
    end
    if animations.model.holdL:isPlaying() then
        models.model.root.torso.body.topbody.arms.leftarm.botarm_L.bothand_L.pivotrotL.LeftItemPivot:setPos(-currentZ/3, currentZ, currentZ/2)
    end
end


function events.tick()
	if world.getTime() % 120 == 0 then
		pings.syncDistance(targetZ)
	end
end
